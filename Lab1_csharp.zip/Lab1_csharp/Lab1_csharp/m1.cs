﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_csharp
{
    public class m1
    {
        public double fraction(double x)
        {
            return (x - (int)x);
        }

        public int charToNum(char x)
        {
            return (x - '0');
        }

        public bool is2Digits(int x)
        {
            if (x < 0)
            {
                x = -x;
            }
            int proverka = x / 10;
            return (proverka <= 9 && proverka >= 1);
        }

        public bool isInRange(int a, int b, int num)
        {
            if (a <= b)
            {
                return num >= a && num <= b;
            }
            else
            {
                return num >= b && num <= a;
            }
        }

        public bool isEqual(int a, int b, int c)
        {
            return (a == b && b == c);
        }

        public int abs(int x)
        {
            if (x >= 0)
            {
                return x;
            }
            else
            {
                return -x;
            }
        }

        public bool is35(int x)
        {
            bool divisibleBy3 = x % 3 == 0;
            bool divisibleBy5 = x % 5 == 0;
            return (divisibleBy3 || divisibleBy5) && !(divisibleBy3 && divisibleBy5);
        }

        public int max3(int x, int y, int z)
        {
            int maxi3;
            if (x > y)
            {
                maxi3 = x;
            }
            else
            {
                maxi3 = y;
            }
            if (maxi3 > z)
            {
                return maxi3;
            }
            else
            {
                return z;
            }
        }

        public int sum2(int x, int y)
        {
            if (x + y <= 19 && x + y >= 10)
            {
                return 20;
            }
            else
            {
                return (x + y);
            }
        }

        public String day(int x)
        {
            switch (x)
            {
                case 1:
                    return "понедельник";
                case 2:
                    return "вторник";
                case 3:
                    return "среда";
                case 4:
                    return "четверг";
                case 5:
                    return "пятница";
                case 6:
                    return "суббота";
                case 7:
                    return "воскресенье";
                default:
                    return "это не день недели";
            }
        }

        public String listNums(int x)
        {
            string s = "";
            for (int i = 0; i <= x; i++)
            {
                s += i;
                s += " ";
            }
            return s;
        }

        public String chet(int x)
        {
            string s = "";
            for (int i = 0; i <= x; i += 2)
            {
                s += i;
                s += " ";
            }
            return s;
        }

        public int numLen(long x)
        {
            int i = 0;
            while (x != 0)
            {
                i += 1;
                x = x / 10;
            }
            return i;
        }

        public static void square(int x)
        {
            int i = 0;
            while (i < x)
            {
                int j = 0;
                while (j < x)
                {
                    Console.Write('*');
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }

            public void rightTriangle(int x)
            {
                int i = 1;

                while (i <= x)
                {
                    int spaces = x - i;
                    int stars = i;
                    int j = 0;
                    while (j < spaces)
                    {
                        Console.Write(' ');
                        j++;
                    }
                    int k = 0;
                    while (k < stars)
                    {
                        Console.Write('*');
                        k++;
                    }

                    Console.WriteLine();
                    i++;
                }
            }

            public int findFirst(int[] arr, int x)
            {
                int i = 0;

                while (i < arr.Length)
                {
                    if (arr[i] == x)
                    {
                        return i;
                    }
                    i++;
                }

                return -1;
            }

            public int maxAbs(int[] arr)
            {
                if (arr.Length == 0)
                {
                    return 0;
                }

                int maxValue = arr[0];

                for (int i = 1; i < arr.Length; i++)
                {
                    int current = arr[i];
                    int currentAbs;
                    int maxAbs;


                    if (current < 0)
                    {
                        currentAbs = -current;
                    }
                    else
                    {
                        currentAbs = current;
                    }

                    if (maxValue < 0)
                    {
                        maxAbs = -maxValue;
                    }
                    else
                    {
                        maxAbs = maxValue;
                    }

                    if (currentAbs > maxAbs)
                    {
                        maxValue = current;
                    }
                }
                Console.WriteLine("Максимальное по модулю значение: " + maxValue);
                return maxValue;
            }

            public int[] add(int[] arr, int[] ins, int pos)
            {
                int[] result = new int[arr.Length + ins.Length];
                int i = 0;
                int j = 0;
                while (j < pos)
                {
                    result[j] = arr[i];
                    i++;
                    j++;
                }
                int k = 0;
                while (k < ins.Length)
                {
                    result[j] = ins[k];
                    k++;
                    j++;
                }

                while (i < arr.Length)
                {
                    result[j] = arr[i];
                    i++;
                    j++;
                }

                return result;
            }

            public int[] reverseBack(int[] arr)
            {
                int[] result = new int[arr.Length];
                int i = 0;
                int j = arr.Length - 1;

                while (i < arr.Length)
                {
                    result[i] = arr[j];
                    i++;
                    j--;
                }

                return result;
            }

            public int[] findAll(int[] arr, int x)
            {

                int count = 0;
                int i = 0;

                while (i < arr.Length)
                {
                    if (arr[i] == x)
                    {
                        count++;
                    }
                    i++;
                }

                int[] result = new int[count];

                int index = 0;
                i = 0;

                while (i < arr.Length)
                {
                    if (arr[i] == x)
                    {
                        result[index] = i;
                        index++;
                    }
                    i++;
                }

                return result;
            }

            public void writemas(int[] arr)
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.Write(arr[i]);
                    Console.Write(" ");
                }
            }

            // Методы для проверки ввода
            public int ReadInt(string message)
            {
                while (true)
                {
                    Console.Write(message);
                    string input = Console.ReadLine();
                    if (int.TryParse(input, out int result))
                    {
                        return result;
                    }
                    Console.WriteLine("Ошибка! Введите целое число.");
                }
            }

            public double ReadDouble(string message)
            {
                while (true)
                {
                    Console.Write(message);
                    string input = Console.ReadLine();
                    if (double.TryParse(input, out double result))
                    {
                        return result;
                    }
                    Console.WriteLine("Ошибка! Введите число с дробной частью.");
                }
            }

            public char ReadChar(string message)
            {
                while (true)
                {
                    Console.Write(message);
                    string input = Console.ReadLine();
                    if (!string.IsNullOrEmpty(input))
                    {
                        return input[0];
                    }
                    Console.WriteLine("Ошибка! Введите хотя бы один символ.");
                }
            }

            public int ReadPositiveInt(string message)
            {
                while (true)
                {
                    Console.Write(message);
                    string input = Console.ReadLine();
                    if (int.TryParse(input, out int result))
                    {
                        if (result > 0)
                        {
                            return result;
                        }
                    }
                    Console.WriteLine("Ошибка! Число должно быть положительным.");
                }
            }
        }
    }
