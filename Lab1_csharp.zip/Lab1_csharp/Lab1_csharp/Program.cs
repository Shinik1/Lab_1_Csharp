﻿using Lab1_csharp;
using System;
using System.Diagnostics.Contracts;

internal class lab1
{
    static void Main()
    {
        m1 m1 = new m1();


        Console.WriteLine("Выберите номер задания");
        Console.WriteLine("Задание 1. Методы");
        Console.WriteLine("Задание 2. Условия");
        Console.WriteLine("Задание 3. Циклы");
        Console.WriteLine("Задание 4. Массивы");

        string taskNumber;
        taskNumber = Console.ReadLine();

        string number;
        Console.WriteLine("Выберите номер задачи (1,3,5,7,9)");
        number = Console.ReadLine();

        switch (taskNumber)
        {
            case "1": // Задание 1. Методы
                {
                    switch (number)
                    {
                        case "1": //Задача 1
                            {
                                double x = m1.ReadDouble("Дробная часть. Введите Х с дробной частью: ");
                                x = double.Parse(Console.ReadLine());
                                double result = m1.fraction(x);
                                Console.Write("Дробная часть: ");
                                Console.WriteLine(result);
                                break;
                            }
                        case "3":
                            {
                                char x = m1.ReadChar("Букву в число. Введите цифру: ");
                                Console.Write("Преобразовали ваш символ в число: ");
                                Console.WriteLine(m1.charToNum(x));
                                break;
                            }
                        case "5":
                            {
                                Console.WriteLine("Двузначное. Введите двузначное число:");
                                int x = int.Parse(Console.ReadLine());
                                Console.WriteLine("Число двузначное?");
                                Console.WriteLine(m1.is2Digits(x));
                                break;
                            }
                        case "7":
                            {
                                int a = m1.ReadInt("Введите a: ");
                                int b = m1.ReadInt("Введите b: ");
                                int num = m1.ReadInt("Введите num: ");
                                Console.WriteLine("Число входит в диапазон?");
                                Console.WriteLine(m1.isInRange(a, b, num));
                                break;
                            }
                        case "9":
                            {
                                Console.WriteLine("Равенство. Введите a b c");
                                int a = m1.ReadInt("Введите a: ");
                                int b = m1.ReadInt("Введите b: ");
                                int c = m1.ReadInt("Введите c: ");
                                Console.WriteLine("Числа равны?");
                                Console.WriteLine(m1.isEqual(a, b, c));
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("Неизвестное число");
                                break;
                            }
                    }
                    break;
                }

            case "2": // Задание 2. Условия
                {
                    switch (number)
                    {
                        case "1":
                            {
                                int x = m1.ReadInt("Модуль числа. Введите X: ");
                                Console.WriteLine(m1.abs(x));
                                break;
                            }
                        case "3":
                            {
                                int x = m1.ReadInt("Тридцать пять. Введите X: ");
                                Console.WriteLine(m1.is35(x));
                                break;
                            }
                        case "5":
                            {
                                Console.WriteLine("Тройной максимум. Введите x,y,z");
                                int x = m1.ReadInt("Введите x: ");
                                int y = m1.ReadInt("Введите y: ");
                                int z = m1.ReadInt("Введите z: ");
                                Console.Write("Максимальное число: ");
                                Console.WriteLine(m1.max3(x, y, z));
                                break;
                            }
                        case "7":
                            {
                                Console.WriteLine("Двойная сумма. Введите x, y");
                                int x = m1.ReadInt("Введите x: ");
                                int y = m1.ReadInt("Введите y: ");
                                Console.WriteLine(m1.sum2(x, y));
                                break;
                            }
                        case "9":
                            {
                                Console.WriteLine("День недели. Введите число");
                                int x = int.Parse(Console.ReadLine());
                                Console.WriteLine(m1.day(x));
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("Неизвестное число");
                                break;
                            }
                    }
                    break;
                }
            case "3": //Задание 3. Циклы
                {
                    switch (number)
                    {
                        case "1":
                            {
                                int x = m1.ReadPositiveInt("Числа подряд. Введите положительное число x: ");
                                Console.WriteLine(m1.listNums(x));
                                break;
                            }
                        case "3":
                            {
                                int x = m1.ReadPositiveInt("Четные числа. Введите положительное число x: ");
                                Console.WriteLine(m1.chet(x));
                                break;
                            }
                        case "5":
                            {
                                int x = m1.ReadPositiveInt("Длина числа. Введите положительное число x: ");
                                Console.WriteLine(m1.numLen(x));
                                break;
                            }
                        case "7":
                            {
                                int x = m1.ReadPositiveInt("Квадрат. Введите положительное число x: ");
                                m1.square(x);
                                break;
                            }
                        case "9":
                            {
                                int x = m1.ReadPositiveInt("Правый треугольник. Введите положительное число x: ");
                                m1.rightTriangle(x);
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("Неизвестное число");
                                break;
                            }
                    }
                    break;
                }

            case "4": //Задание 4. Массивы
                {

                    int[] arr = new int[10];
                    Console.WriteLine("arr");
                    Random random = new Random();
                    for (int i = 0; i < arr.Length; i++)
                    {
                        arr[i] = random.Next(10, 11);
                        Console.Write(arr[i]);
                        Console.Write(" ");
                    }

                    Console.WriteLine("");



                    switch (number)
                    {
                        case "1":
                            {
                                int x = m1.ReadInt("Введите число х: ");
                                Console.WriteLine("Первое вхождение в массив: ");
                                Console.WriteLine(m1.findFirst(arr, x));
                                break;
                            }
                        case "3":
                            {
                                int x;
                                x = m1.maxAbs(arr);
                                Console.WriteLine(x);
                                break;
                            }
                        case "5":
                            {
                                int[] ins = new int[10];
                                Console.WriteLine("ins");
                                for (int i = 0; i < ins.Length; i++)
                                {
                                    ins[i] = random.Next(-100, 100);
                                    Console.Write(ins[i]);
                                    Console.Write(" ");
                                }

                                Console.WriteLine("");

                                int x;
                                int[] arc;
                                Console.WriteLine("Введите число х, что бы в массиве arr вставить в эту позицию массив ins");
                                x = int.Parse(Console.ReadLine());
                                arc = m1.add(arr, ins, x);
                                m1.writemas(arc);
                                break;
                            }

                        case "7":
                            {
                                int[] arc;
                                arc = m1.reverseBack(arr);
                                m1.writemas(arc);
                                break;
                            }

                        case "9":
                            {
                                int[] arc;
                                int x = m1.ReadInt("Введите число х: ");
                                Console.WriteLine("Все вхождения x");
                                arc = m1.findAll(arr, x);
                                m1.writemas(arc);
                                break;
                            }

                        default:
                            {
                                Console.WriteLine("Неизвестное число");
                                break;
                            }
                    }

                    break;
                }

        }

    }
}